# Idempotent Background Transaction Processing Service (FDE L2)

A Java 17 + Maven reference implementation for the practical FDE assessment. It demonstrates idempotency, per-account sequence ordering, validation, retry-safe processing, status reporting, and unit tests. It intentionally uses in-memory storage so it can be run without paid services or infrastructure.

## Requirements
- JDK 17+
- Maven 3.8+

## Run
```bash
mvn clean test
mvn exec:java
```

## What the demo does
1. Receives a batch of transaction requests from a replaceable in-code input adapter.
2. Validates required identifiers, transaction type, positive amount, currency, and sequence.
3. Buffers future sequence numbers until the missing earlier sequence arrives. Sequence numbers start at 1 independently for each account.
4. Uses `transactionId` as the business idempotency key and `requestId` to recognize a replayed request.
5. Simulates a transient failure on the first attempt for TXN-2005, then retries successfully (maximum 3 attempts).
6. Applies a credit/debit and advances the account sequence inside a synchronized processing path.
7. Prints statuses, balances, and a status-event summary.

## Design decisions
- **Idempotency:** A processed business `transactionId` is remembered. A later request for that transaction is marked `DUPLICATE` and cannot change the balance again. A repeated `requestId` is also detected.
- **Ordering:** Sequence numbers are contiguous and start at 1 per account. A future sequence is buffered as `PENDING_SEQUENCE`; when the missing sequence is processed, the processor drains consecutive buffered records. This is deliberately simple and deterministic.
- **Retries:** The sample injects one transient failure. The processor records `RETRY_PENDING`, retries, and only applies the balance effect after a successful attempt. The retry cap is 3.
- **Consistency:** The demo serializes processing in-process. A real implementation must atomically persist the idempotency record, ledger entry, account balance, and sequence checkpoint in one database transaction.
- **Isolation:** Invalid input fails independently; it does not terminate the batch.
- **Observability:** Java logs identify processing attempts and outcomes. The console prints result events, balances, and counts by status.

## Important assumptions / trade-offs
- This is a single-process demonstration. In-memory data is lost on restart and does not coordinate multiple application instances.
- The sequence policy assumes a per-account sequence beginning at 1. A production contract must define who assigns sequences, how gaps are timed out/escalated, and how corrections/reversals work.
- The current sample models CREDIT and DEBIT only. Reversal support should use a linked original transaction and a unique reversal idempotency key.
- The summary counts recorded status events, not only each transaction's final status. This makes retry/pending lifecycle events visible; production dashboards should separately expose final-state counts and event counters.
- A failed transaction advances the sequence in this simplified demo to avoid blocking later work. A real banking domain may instead quarantine the account stream until an operator resolves the failed event. This is a business decision, not a universal rule.

## Suggested production hardening
1. Replace the in-memory store with PostgreSQL or another ACID database. Add unique constraints on `transaction_id` and `request_id`.
2. In one database transaction, insert a ledger row, update the balance, mark the request processed, and advance the sequence. Use optimistic locking or row-level locks for concurrent account updates.
3. Use a queue adapter (Kafka, SQS, RabbitMQ, etc.) with at-least-once delivery; retain database idempotency because queues can redeliver.
4. Persist pending/retry records and implement exponential backoff with jitter, maximum attempts, dead-letter handling, and operator replay.
5. Add structured JSON logs, correlation IDs, metrics (processed/duplicate/failed/retry/gap counts), tracing, health checks, and alerts.
6. Add authentication/authorization, input size limits, encryption, retention policies, and avoid logging personal or financial data.
7. Add integration, concurrency, restart/recovery, and contract tests.

## Project structure
```text
src/main/java/com/assessment/fde/
  app/       TransactionApplication.java  # demo entry point / input adapter
  model/     TransactionRequest.java, TransactionResult.java, enums
  service/   TransactionProcessor.java    # validation, ordering, idempotency, retry
  store/     InMemoryTransactionStore.java
src/test/java/.../TransactionProcessorTest.java
```

## Assessment walkthrough
- Start with `TransactionApplication` to see the sample batch and input boundary.
- Read `TransactionProcessor.submit()` for validation, duplicate detection, and sequence decisions.
- Read `processInOrder()` for retry and balance application.
- Read `InMemoryTransactionStore` for the demo persistence boundary.
- Run `mvn clean test` to execute the five core tests.

## AI-assisted development disclosure
AI assistance was used to accelerate project scaffolding, generate an initial implementation outline, and review test scenarios. The implementation was then checked against the assessment requirements, with explicit tests for duplicate delivery, out-of-order sequence arrival, invalid amount, transient retry, and insufficient funds. The candidate should personally run the project, inspect the code, and be prepared to explain every design decision before submission.
