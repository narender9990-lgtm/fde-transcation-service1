package com.assessment.fde.service;

import com.assessment.fde.model.*;
import com.assessment.fde.store.InMemoryTransactionStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class TransactionProcessorTest {
    private TransactionProcessor processor;
    @BeforeEach void setup() { processor = new TransactionProcessor(new InMemoryTransactionStore()); }
    private TransactionRequest tx(String id, String req, String account, TransactionType type, String amount, long seq, boolean fail) {
        return new TransactionRequest(id, req, account, type, new BigDecimal(amount), "INR", seq, fail);
    }
    @Test void duplicateBusinessTransactionDoesNotApplyBalanceTwice() {
        assertEquals(TransactionStatus.PROCESSED, processor.submit(tx("T1","R1","A1",TransactionType.CREDIT,"100",1,false)).status());
        assertEquals(TransactionStatus.DUPLICATE, processor.submit(tx("T1","R2","A1",TransactionType.CREDIT,"100",1,false)).status());
        assertEquals(new BigDecimal("100"), processor.balance("A1"));
    }
    @Test void buffersFutureSequenceAndDrainsAfterGapArrives() {
        assertEquals(TransactionStatus.PENDING_SEQUENCE, processor.submit(tx("T2","R2","A1",TransactionType.DEBIT,"40",2,false)).status());
        assertEquals(TransactionStatus.PROCESSED, processor.submit(tx("T1","R1","A1",TransactionType.CREDIT,"100",1,false)).status());
        assertEquals(new BigDecimal("60"), processor.balance("A1"));
    }
    @Test void invalidAmountIsRejectedWithoutChangingBalance() {
        assertEquals(TransactionStatus.FAILED, processor.submit(tx("T1","R1","A1",TransactionType.CREDIT,"-5",1,false)).status());
        assertEquals(BigDecimal.ZERO, processor.balance("A1"));
    }
    @Test void transientFailureRetriesWithoutDuplicateEffect() {
        TransactionResult result = processor.submit(tx("T1","R1","A1",TransactionType.CREDIT,"50",1,true));
        assertEquals(TransactionStatus.PROCESSED, result.status());
        assertEquals(2, result.attempts());
        assertEquals(new BigDecimal("50"), processor.balance("A1"));
    }
    @Test void debitCannotOverdrawAccount() {
        TransactionResult result = processor.submit(tx("T1","R1","A1",TransactionType.DEBIT,"10",1,false));
        assertEquals(TransactionStatus.FAILED, result.status());
        assertEquals(BigDecimal.ZERO, processor.balance("A1"));
    }
}
