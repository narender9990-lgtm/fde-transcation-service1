package com.assessment.fde.model;
public enum TransactionStatus { RECEIVED, PROCESSING, PROCESSED, DUPLICATE, FAILED, RETRY_PENDING, PENDING_SEQUENCE }
