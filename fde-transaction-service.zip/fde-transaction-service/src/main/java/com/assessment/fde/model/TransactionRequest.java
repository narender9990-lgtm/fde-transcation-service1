package com.assessment.fde.model;
import java.math.BigDecimal;

public record TransactionRequest(String transactionId, String requestId, String accountId,
        TransactionType transactionType, BigDecimal amount, String currency, long sequenceNumber,
        boolean simulateTransientFailure) { }
