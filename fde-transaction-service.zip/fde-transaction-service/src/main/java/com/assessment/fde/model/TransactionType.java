package com.assessment.fde.model;
public enum TransactionType { CREDIT, DEBIT }
