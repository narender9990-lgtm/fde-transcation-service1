package com.assessment.fde.app;

import com.assessment.fde.model.*;
import com.assessment.fde.service.TransactionProcessor;
import com.assessment.fde.store.InMemoryTransactionStore;
import java.math.BigDecimal;
import java.util.List;

public class TransactionApplication {
    public static void main(String[] args) {
        InMemoryTransactionStore store = new InMemoryTransactionStore();
        TransactionProcessor processor = new TransactionProcessor(store);
        // Replace this list with a CSV reader, REST adapter, or queue consumer when integrating a real source.
        List<TransactionRequest> batch = List.of(
            tx("TXN-2002", "REQ-2", "ACC-201", TransactionType.DEBIT, "40", 2, false),
            tx("TXN-2001", "REQ-1", "ACC-201", TransactionType.CREDIT, "100", 1, false),
            tx("TXN-2002", "REQ-2-DUP", "ACC-201", TransactionType.DEBIT, "40", 2, false),
            tx("TXN-2003", "REQ-3", "ACC-201", TransactionType.CREDIT, "25", 3, false),
            tx("TXN-2004", "REQ-4", "ACC-202", TransactionType.DEBIT, "-10", 1, false),
            tx("TXN-2005", "REQ-5", "ACC-203", TransactionType.CREDIT, "500", 1, true)
        );
        System.out.println("=== TRANSACTION PROCESSING ===");
        for (TransactionRequest request : batch) {
            TransactionResult r = processor.submit(request);
            System.out.printf("%s | %s | attempts=%d | %s%n", r.transactionId(), r.status(), r.attempts(), r.message());
        }
        System.out.println("\n=== ACCOUNT BALANCES ===");
        for (String account : List.of("ACC-201", "ACC-202", "ACC-203"))
            System.out.println(account + " = " + processor.balance(account));
        System.out.println("\n=== STATUS SUMMARY (event counts) ===");
        processor.summary().forEach((status, count) -> System.out.println(status + " = " + count));
        System.out.println("\nNote: PENDING_SEQUENCE and RETRY_PENDING are lifecycle events; summary counts recorded status events.");
    }
    private static TransactionRequest tx(String txn, String req, String account, TransactionType type,
            String amount, long sequence, boolean failOnce) {
        return new TransactionRequest(txn, req, account, type, new BigDecimal(amount), "INR", sequence, failOnce);
    }
}
