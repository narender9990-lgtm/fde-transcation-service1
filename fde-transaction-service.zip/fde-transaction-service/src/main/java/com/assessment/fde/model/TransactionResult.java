package com.assessment.fde.model;
public record TransactionResult(String transactionId, String requestId, String accountId,
        TransactionStatus status, int attempts, String message) { }
