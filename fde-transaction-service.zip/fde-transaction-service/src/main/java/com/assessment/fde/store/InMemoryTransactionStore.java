package com.assessment.fde.store;

import com.assessment.fde.model.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory demonstration store. Replace with a transactional database in production. */
public class InMemoryTransactionStore {
    private final Map<String, TransactionResult> byTransactionId = new ConcurrentHashMap<>();
    private final Map<String, TransactionResult> byRequestId = new ConcurrentHashMap<>();
    private final Map<String, BigDecimal> balances = new ConcurrentHashMap<>();
    private final Map<String, Long> nextSequenceByAccount = new ConcurrentHashMap<>();
    private final List<TransactionResult> history = Collections.synchronizedList(new ArrayList<>());

    public synchronized boolean isTransactionProcessed(String id) {
        TransactionResult r = byTransactionId.get(id);
        return r != null && r.status() == TransactionStatus.PROCESSED;
    }
    public synchronized boolean isRequestSeen(String id) { return byRequestId.containsKey(id); }
    public synchronized void record(TransactionResult result) {
        byRequestId.put(result.requestId(), result);
        if (result.status() == TransactionStatus.PROCESSED) byTransactionId.put(result.transactionId(), result);
        history.add(result);
    }
    public synchronized void updateStatus(TransactionResult result) {
        byRequestId.put(result.requestId(), result);
        if (result.status() == TransactionStatus.PROCESSED) byTransactionId.put(result.transactionId(), result);
        history.add(result);
    }
    public synchronized BigDecimal balance(String accountId) { return balances.getOrDefault(accountId, BigDecimal.ZERO); }
    public synchronized void apply(String accountId, BigDecimal delta) { balances.put(accountId, balance(accountId).add(delta)); }
    public synchronized long expectedSequence(String accountId) { return nextSequenceByAccount.getOrDefault(accountId, 1L); }
    public synchronized void advanceSequence(String accountId) { nextSequenceByAccount.put(accountId, expectedSequence(accountId) + 1); }
    public List<TransactionResult> history() { synchronized(history) { return List.copyOf(history); } }
}
