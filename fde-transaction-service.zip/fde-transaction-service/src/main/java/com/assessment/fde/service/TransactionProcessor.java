package com.assessment.fde.service;

import com.assessment.fde.model.*;
import com.assessment.fde.store.InMemoryTransactionStore;
import java.math.BigDecimal;
import java.util.*;
import java.util.logging.Logger;

/** Sequence-based processor: sequence numbers are contiguous and start at 1 per account. */
public class TransactionProcessor {
    private static final Logger LOG = Logger.getLogger(TransactionProcessor.class.getName());
    private static final int MAX_ATTEMPTS = 3;
    private final InMemoryTransactionStore store;
    private final Map<String, TreeMap<Long, TransactionRequest>> pending = new HashMap<>();
    private final Map<String, Integer> attempts = new HashMap<>();

    public TransactionProcessor(InMemoryTransactionStore store) { this.store = Objects.requireNonNull(store); }

    public synchronized TransactionResult submit(TransactionRequest request) {
        String validationError = validate(request);
        if (validationError != null) { TransactionResult invalid = result(request, TransactionStatus.FAILED, 0, validationError); store.record(invalid); return invalid; }
        if (store.isRequestSeen(request.requestId())) { TransactionResult duplicate = result(request, TransactionStatus.DUPLICATE, 0, "Request ID already received"); store.record(duplicate); return duplicate; }
        if (store.isTransactionProcessed(request.transactionId())) { TransactionResult duplicate = result(request, TransactionStatus.DUPLICATE, 0, "Business transaction already processed"); store.record(duplicate); return duplicate; }

        long expected = store.expectedSequence(request.accountId());
        if (request.sequenceNumber() > expected) {
            pending.computeIfAbsent(request.accountId(), k -> new TreeMap<>()).putIfAbsent(request.sequenceNumber(), request);
            TransactionResult r = result(request, TransactionStatus.PENDING_SEQUENCE, 0,
                    "Waiting for sequence " + expected + "; received " + request.sequenceNumber());
            store.record(r); LOG.info(() -> "PENDING_SEQUENCE transaction=" + request.transactionId()); return r;
        }
        if (request.sequenceNumber() < expected) { TransactionResult stale = result(request, TransactionStatus.DUPLICATE, 0, "Stale sequence number"); store.record(stale); return stale; }
        TransactionResult result = processInOrder(request);
        drain(request.accountId());
        return result;
    }

    private void drain(String accountId) {
        TreeMap<Long, TransactionRequest> queue = pending.get(accountId);
        while (queue != null) {
            TransactionRequest next = queue.remove(store.expectedSequence(accountId));
            if (next == null) break;
            processInOrder(next);
        }
        if (queue != null && queue.isEmpty()) pending.remove(accountId);
    }

    private TransactionResult processInOrder(TransactionRequest request) {
        String key = request.transactionId();
        int count = attempts.getOrDefault(key, 0);
        for (int attempt = count + 1; attempt <= MAX_ATTEMPTS; attempt++) {
            attempts.put(key, attempt);
            LOG.info("PROCESSING transaction=" + request.transactionId() + " attempt=" + attempt);
            if (request.simulateTransientFailure() && attempt == 1) {
                TransactionResult retry = result(request, TransactionStatus.RETRY_PENDING, attempt, "Simulated transient failure; retrying");
                store.updateStatus(retry);
                continue;
            }
            BigDecimal delta = request.transactionType() == TransactionType.CREDIT ? request.amount() : request.amount().negate();
            if (request.transactionType() == TransactionType.DEBIT && store.balance(request.accountId()).compareTo(request.amount()) < 0) {
                TransactionResult failed = result(request, TransactionStatus.FAILED, attempt, "Insufficient funds");
                store.updateStatus(failed); store.advanceSequence(request.accountId()); return failed;
            }
            // This synchronized critical section simulates an atomic ledger + balance transaction.
            store.apply(request.accountId(), delta);
            TransactionResult success = result(request, TransactionStatus.PROCESSED, attempt, "Transaction processed");
            store.updateStatus(success); store.advanceSequence(request.accountId());
            LOG.info(() -> "PROCESSED transaction=" + request.transactionId());
            return success;
        }
        TransactionResult failed = result(request, TransactionStatus.FAILED, MAX_ATTEMPTS, "Retry limit exhausted");
        store.updateStatus(failed); store.advanceSequence(request.accountId()); return failed;
    }

    private String validate(TransactionRequest r) {
        if (r == null) return "Request is null";
        if (blank(r.transactionId()) || blank(r.requestId()) || blank(r.accountId())) return "transactionId, requestId and accountId are required";
        if (r.transactionType() == null) return "transactionType is required";
        if (r.amount() == null || r.amount().compareTo(BigDecimal.ZERO) <= 0) return "amount must be greater than zero";
        if (blank(r.currency()) || !r.currency().matches("[A-Z]{3}")) return "currency must be a 3-letter uppercase code";
        if (r.sequenceNumber() < 1) return "sequenceNumber must be >= 1";
        return null;
    }
    private boolean blank(String s) { return s == null || s.isBlank(); }
    private TransactionResult result(TransactionRequest r, TransactionStatus status, int attempts, String msg) {
        return new TransactionResult(r == null ? "UNKNOWN" : r.transactionId(), r == null ? "UNKNOWN" : r.requestId(),
                r == null ? "UNKNOWN" : r.accountId(), status, attempts, msg);
    }
    public BigDecimal balance(String accountId) { return store.balance(accountId); }
    public List<TransactionResult> results() { return store.history(); }
    public Map<TransactionStatus, Long> summary() {
        Map<TransactionStatus, Long> counts = new EnumMap<>(TransactionStatus.class);
        for (TransactionStatus s : TransactionStatus.values()) counts.put(s, 0L);
        for (TransactionResult r : store.history()) counts.merge(r.status(), 1L, Long::sum);
        return counts;
    }
    public synchronized void retryPending(String transactionId) { /* retry is automatic in this demo; hook for persisted retry worker */ }
}
