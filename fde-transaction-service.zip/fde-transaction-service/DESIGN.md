# Design Note — FDE L2 Transaction Processor

## Architecture
The application has four layers: an input adapter (demo batch in `TransactionApplication`), domain models, `TransactionProcessor` business logic, and `InMemoryTransactionStore` persistence. The input adapter can later be replaced by a REST endpoint, file reader, scheduler, or queue consumer without changing the core processor contract.

## Idempotency and duplicates
`transactionId` is the business-level idempotency key: once it reaches `PROCESSED`, subsequent requests for the same ID are rejected as `DUPLICATE`. `requestId` detects replay of the same delivery request. In production both identifiers require durable unique constraints and the ledger/balance mutation must commit atomically.

## Ordering
The implementation uses per-account contiguous sequence numbers starting at 1. A future event is buffered. When the expected event arrives, the processor applies it and drains any now-contiguous buffered events. This makes the sample's sequence 2-before-1 case deterministic. Gaps remain pending; production needs a gap timeout, alert, and recovery procedure.

## Retry and failure handling
A transient failure is injected for the first attempt of a configured record. The processor records `RETRY_PENDING`, retries up to three attempts, and only changes the balance after the attempt succeeds. Validation failures and insufficient-funds failures are isolated to their own records. A production worker should persist retry state, use backoff/jitter, and move exhausted records to a dead-letter queue for controlled replay.

## Consistency and concurrency
The demo serializes calls in a single JVM. This prevents concurrent duplicate effects only within this process. Production must use an ACID database transaction covering idempotency claim, ledger insert, balance update, and sequence checkpoint; row locks or optimistic version checks should protect concurrent updates to the same account. External side effects should use an outbox pattern.

## Observability and security
The demo emits processing logs and prints statuses, balances, and status-event counts. Production should use structured logs with correlation IDs, metrics, distributed traces, alerts, and operational dashboards. Do not log full account/customer data; validate at the boundary, protect secrets, and enforce access controls.

## Known limitations
Storage is in-memory; restart loses state. No real broker/database is configured. Sequence policy starts at 1 per account. The sample includes CREDIT/DEBIT but not reversal. The summary counts status events, so a transaction can contribute more than one event (for example, `RETRY_PENDING` then `PROCESSED`). The demo advances the sequence after a terminal business failure; a real product owner must decide whether failed events should block the account stream or be quarantined.

## AI-assisted development
AI was used for scaffolding and a first-pass implementation/test checklist. The code and test scenarios must be run and reviewed by the candidate. The candidate should be able to explain the idempotency key, sequence-gap policy, retry cap, in-memory limitation, and the production database transaction boundary.
